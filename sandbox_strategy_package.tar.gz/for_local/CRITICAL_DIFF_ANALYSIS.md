# 샌드박스 vs 로컬 핵심 차이점 분석 (4가지)

> **작성일**: 2026-01-12  
> **목적**: 샌드박스 승률 86% vs 로컬 승률 27~48% 차이 원인 분석

---

## 핵심 차이점 요약 표

| # | 항목 | 샌드박스 원본 | 로컬 구현 | 영향 |
|---|------|---------------|-----------|------|
| 1 | **파라미터 키** | `trail_start`, `trail_dist` | `trail_start_r`, `trail_dist_r` | 키 불일치로 기본값 사용 |
| 2 | **함수 구조** | 단일 `run_backtest_core()` | 분리된 `simulate_trades()` | 로직 분산 |
| 3 | **PnL 단위** | Decimal (0.01 = 1%) | Percent (1.23 = 1.23%) | ⚠️ 이중 변환 가능성 |
| 4 | **MDD 계산** | numpy 벡터 연산 | 스칼라 루프 | 계산 방식 차이 |

---

## 1. 파라미터 키 불일치 (치명적)

### 샌드박스 원본 (sandbox_backtest_v4.py Line 382-383)
```python
trail_start_r = params.get('trail_start', 1.2)   # 키: 'trail_start'
trail_dist_r = params.get('trail_dist', 0.03)    # 키: 'trail_dist'
```

### 로컬 예상 (확인 필요)
```python
trail_start_r = params.get('trail_start_r', 0.8)  # 키: 'trail_start_r' (다름!)
trail_dist_r = params.get('trail_dist_r', 0.1)    # 키: 'trail_dist_r' (다름!)
```

### 영향
- 로컬에서 `trail_start`로 전달해도 `trail_start_r`를 읽으면 기본값 사용
- 기본값 0.8 vs 1.2, 0.1 vs 0.03 → 완전히 다른 트레일링 동작

### 수정 방법
```python
# 로컬 코드에서 두 키 모두 지원하도록 수정
trail_start_r = params.get('trail_start_r', params.get('trail_start', 1.2))
trail_dist_r = params.get('trail_dist_r', params.get('trail_dist', 0.03))
```

---

## 2. PnL 단위 차이 (치명적)

### 샌드박스 원본 (Line 479-487)
```python
# PnL은 소수 (0.05 = 5%)
if direction == 'Long':
    entry_adj = entry_price * (1 + slippage)
    exit_adj = exit_price * (1 - slippage)
    pnl_pct = (exit_adj - entry_adj) / entry_adj - fee * 2
else:
    entry_adj = entry_price * (1 - slippage)
    exit_adj = exit_price * (1 + slippage)
    pnl_pct = (entry_adj - exit_adj) / entry_adj - fee * 2

# 복리 계산시
capital *= (1 + pnl_pct)  # pnl_pct가 0.05면 1.05배

# 최종 출력시 100 곱함 (Line 517-518)
simple_pnl = sum(pnls) * 100      # 0.05 * 100 = 5%
compound_pnl = (equity[-1] / initial_capital - 1) * 100
```

### 로컬 예상 문제
```python
# 만약 로컬에서 pnl_pct를 이미 퍼센트로 저장하면
pnl_pct = ((exit_adj - entry_adj) / entry_adj - fee * 2) * 100  # 5.0

# 복리 계산시 오류 발생!
capital *= (1 + pnl_pct)  # 5.0이면 6배가 됨 (오류!)
```

### 확인 코드 (로컬에서 실행)
```python
# 로컬 코드에서 이 부분을 찾아서 확인
# 검색 키워드: "pnl_pct", "* 100", "capital *="
```

### 수정 방법
```python
# 샌드박스와 동일하게: PnL은 항상 소수로 저장, 출력시에만 100 곱함
pnl_pct = (exit_adj - entry_adj) / entry_adj - fee * 2  # 소수 유지 (0.05)
# 출력시
result['simple_pnl'] = sum(pnls) * 100  # 5.0%
```

---

## 3. MDD 계산 방식 차이

### 샌드박스 원본 (Line 506-519)
```python
capital = initial_capital
equity = [capital]
for pnl in pnls:
    capital *= (1 + pnl)
    equity.append(capital)

equity = np.array(equity)
peak = np.maximum.accumulate(equity)  # numpy 벡터 연산
drawdown = (equity - peak) / peak * 100
max_dd = abs(drawdown.min())
```

### 로컬 예상 (스칼라 방식)
```python
equity = 100.0
max_dd = 0.0
peak = 100.0
for pnl in pnls:
    equity *= (1 + pnl)
    if equity > peak:
        peak = equity
    dd = (peak - equity) / peak * 100
    if dd > max_dd:
        max_dd = dd
```

### 차이점
- 결과값은 동일해야 하지만, 스칼라 방식에서 실수 가능성 있음
- 샌드박스는 전체 시퀀스 저장, 로컬은 현재값만 유지

---

## 4. 함수 구조 차이

### 샌드박스 원본
```
run_single_tf_backtest()
  └─> calculate_indicators()
  └─> prepare_data()
  └─> extract_patterns_adxdi() 또는 extract_patterns_macd()
  └─> run_backtest_core()  ← 단일 함수에서 모든 로직 처리
```

### 로컬 예상
```
run_backtest()
  └─> _calculate_indicators()
  └─> _extract_patterns()
  └─> simulate_trades()  ← 분리된 함수
        └─> _filter_signal()
        └─> _calculate_pnl()
```

### 영향
- 함수 분리로 인한 데이터 전달 과정에서 손실 또는 변형 가능
- 디버깅 어려움

---

## 로컬 AI 확인 요청 사항

### 1) 파라미터 키 확인
```python
# 로컬 strategy_core.py에서 검색
grep -n "trail_start" strategy_core.py
grep -n "trail_dist" strategy_core.py
```

**보고 형식:**
```
라인 번호: XXX
코드: trail_start_r = params.get('???', ???)
```

### 2) PnL 계산 확인
```python
# 로컬 strategy_core.py에서 검색
grep -n "pnl_pct" strategy_core.py
grep -n "\* 100" strategy_core.py
grep -n "capital \*=" strategy_core.py
```

**보고 형식:**
```
라인 번호: XXX
PnL 계산: pnl_pct = ???
PnL 단위: 소수 / 퍼센트
복리 계산: capital *= (1 + pnl_pct)에서 pnl_pct 단위는?
```

### 3) MDD 계산 확인
```python
# 로컬에서 검색
grep -n "max_dd\|drawdown\|mdd" strategy_core.py
```

---

## 즉시 적용할 수정 사항 (우선순위)

### 1순위: 파라미터 키 통일
```python
# 두 키 모두 지원
trail_start_r = params.get('trail_start_r', params.get('trail_start', 1.2))
trail_dist_r = params.get('trail_dist_r', params.get('trail_dist', 0.03))
```

### 2순위: PnL 단위 확인 및 수정
```python
# 반드시 소수로 저장
pnl_pct = (exit_adj - entry_adj) / entry_adj - fee * 2  # 0.05 형식
# 절대 여기서 * 100 하지 않음
```

### 3순위: 샌드박스 파라미터 사용
```python
SANDBOX_PARAMS = {
    'trail_start': 1.2,      # 키 주의!
    'trail_dist': 0.03,      # 키 주의!
    'adx_min': 10,
    'atr_mult': 1.5,
    'max_bars': 100,
}
```

---

## 테스트 검증 코드

로컬에서 아래 코드 실행하여 확인:

```python
# 단일 거래 PnL 검증
entry = 50000
exit_price = 52500  # +5%
slippage = 0.0006
fee = 0.00055

# 샌드박스 공식
entry_adj = entry * (1 + slippage)
exit_adj = exit_price * (1 - slippage)
pnl_pct = (exit_adj - entry_adj) / entry_adj - fee * 2

print(f"PnL (소수): {pnl_pct:.4f}")      # 예상: 0.0477
print(f"PnL (퍼센트): {pnl_pct*100:.2f}%")  # 예상: 4.77%

# 복리 계산 검증
capital = 10000
capital *= (1 + pnl_pct)
print(f"복리 후 자본: {capital:.2f}")   # 예상: 10477.xx
```

---

## 결론

**샌드박스 86% 승률 vs 로컬 27~48% 승률** 차이의 주요 원인:

1. **파라미터 키 불일치** → 트레일링이 완전히 다르게 동작
2. **PnL 단위 혼동** → 복리 계산 오류 가능성
3. **MDD/성과 계산** → 미세 차이 누적

**권장 해결책:**
1. 샌드박스 원본 파일(`sandbox_backtest_v4.py`)을 로컬에 그대로 복사
2. 로컬 strategy_core.py 대신 샌드박스 모듈 직접 사용
3. 결과 동일해질 때까지 키/공식 맞춤

---

## 파일 체크리스트

| 파일 | 확인 사항 | 상태 |
|------|-----------|------|
| strategy_core.py | trail_start vs trail_start_r 키 | ⬜ |
| strategy_core.py | pnl_pct 단위 (소수/퍼센트) | ⬜ |
| strategy_core.py | capital *= (1 + pnl_pct) | ⬜ |
| calculations.py | PnL 공식 | ⬜ |
| parameters.py | 파라미터 키 이름 | ⬜ |

---

*이 문서를 로컬 AI에게 전달하여 차이점 확인 후 수정 요청*
