# 샌드박스 vs 로컬 최종 비교 보고서

> **작성일**: 2026-01-12  
> **핵심 발견**: 데이터 기간 차이 + 패턴 추출 로직 차이

---

## 1. 데이터 기간별 샌드박스 결과

### MACD 방식

| 기간 | 거래수 | 승률 | PnL | MDD |
|------|--------|------|-----|-----|
| **2024년만** (1년) | 165 | 86.1% | +1,670% | 5.9% |
| **2024년~** (2년) | 349 | 85.7% | +25,640% | 6.5% |
| **전체** (5.79년) | 1,001 | 86.2% | 천문학적 | 7.7% |

### ADX/DI 방식

| 기간 | 거래수 | 승률 | PnL | MDD |
|------|--------|------|-----|-----|
| **2024년만** (1년) | 217 | 80.2% | +2,760% | 8.4% |
| **2024년~** (2년) | 427 | 82.0% | +47,563% | 8.4% |
| **전체** (5.79년) | 1,253 | 81.2% | 천문학적 | 14.4% |

---

## 2. 로컬 vs 샌드박스 비교 (동일 조건)

### 테스트 조건: 5.79년 전체 데이터

| 항목 | 샌드박스 | 로컬 | 차이 |
|------|----------|------|------|
| **MACD 거래수** | 1,001 | 5,091 | ⚠️ 5배↑ |
| **MACD 승률** | 86.2% | 46.0% | ⚠️ 40%↓ |
| **ADX/DI 거래수** | 1,253 | 3,996 | ⚠️ 3배↑ |
| **ADX/DI 승률** | 81.2% | 46.2% | ⚠️ 35%↓ |

---

## 3. 핵심 차이점 원인

### 원인 1: 패턴 추출 로직 차이

**샌드박스 패턴 수** (5.79년, 2h TF):
- ADX/DI: ~1,500 패턴 → 1,253 거래 (83% 통과)
- MACD: ~1,200 패턴 → 1,001 거래 (83% 통과)

**로컬 패턴 수** (예상):
- ADX/DI: ~5,000+ 패턴 → 3,996 거래
- MACD: ~6,000+ 패턴 → 5,091 거래

**결론**: 로컬이 너무 많은 패턴을 생성함 → **노이즈 포함**

### 원인 2: 필터 적용 차이

**샌드박스 필터** (run_backtest_core):
```python
# 1. ADX 필터 (이중 체크)
if adx_min > 0 and (pd.isna(row['adx']) or row['adx'] < adx_min):
    passed = False

# 2. 스토캐스틱 필터
if direction == 'Long' and stoch_long_max < 100:
    if row['stoch_k'] > stoch_long_max:
        passed = False

# 3. 하락추세 필터 (Short만)
if direction == 'Short' and not row.get('downtrend', False):
    passed = False
```

**로컬 필터 확인 필요**:
- 스토캐스틱 필터가 적용되는지?
- downtrend 필터가 적용되는지?
- ADX 이중 체크가 되는지?

### 원인 3: 데이터 기간 차이

| 기간 | 시장 상황 | 전략 적합도 |
|------|-----------|------------|
| 2020 | 코로나 폭락→회복 | 변동성 큼 |
| 2021 | 강세장 ATH | ⭐ 최적 |
| 2022 | 약세장 | ❌ 손실 구간 |
| 2023 | 횡보 | 보통 |
| 2024 | 강세장 | ⭐ 최적 |
| 2025 | 진행 중 | 보통 |

---

## 4. 로컬 AI에게 전달할 수정 요청

### 확인 사항 1: 패턴 수 비교

```python
# 로컬에서 실행
patterns = _extract_patterns(df)
print(f"패턴 수: {len(patterns)}")

# 샌드박스 예상: 5.79년 기준
# - ADX/DI: ~1,500
# - MACD: ~1,200
```

### 확인 사항 2: 필터 적용 여부

```python
# 로컬 strategy_core.py에서 검색
grep -n "stoch_k\|stoch_long_max" strategy_core.py
grep -n "downtrend" strategy_core.py
```

### 수정 사항: 필터 추가

```python
# 로컬 코드에 아래 필터 추가
# 1. 스토캐스틱 필터
if direction == 'Long' and row['stoch_k'] > 50:
    continue  # 과매수시 Long 제외
    
if direction == 'Short' and row['stoch_k'] < 50:
    continue  # 과매도시 Short 제외

# 2. 하락추세 필터 (Short만)
if direction == 'Short' and not row.get('downtrend', False):
    continue
```

---

## 5. 가장 확실한 해결책

### 옵션 A: 샌드박스 모듈 직접 사용 (권장)

```python
# 로컬에서
from core.sandbox_backtest_v4 import run_single_tf_backtest, SANDBOX_PARAMS

result = run_single_tf_backtest(df, SANDBOX_PARAMS, timeframe='2h', method='macd')
```

### 옵션 B: 로컬 코드를 샌드박스 기준으로 수정

1. `detect_patterns_adxdi()` 함수 교체
2. `detect_patterns_macd()` 함수 교체
3. `run_backtest_core()` 필터 로직 추가

### 옵션 C: 2024년~ 데이터만 사용

로컬에서 데이터 필터링:
```python
df = df[df['timestamp'] >= '2024-01-01']
```

---

## 6. 기대 결과 (수정 후)

### 로컬에서 샌드박스 모듈 사용시

| 기간 | 방식 | 거래수 | 승률 | PnL | MDD |
|------|------|--------|------|-----|-----|
| 2024년만 | MACD | ~165 | ~86% | ~1,670% | ~6% |
| 2024년~ | MACD | ~349 | ~86% | ~25,640% | ~6.5% |

---

## 7. 요약

| 문제 | 원인 | 해결책 |
|------|------|--------|
| 거래수 3-5배 차이 | 패턴 추출 로직 차이 | 샌드박스 함수 복사 |
| 승률 40% 차이 | 필터 미적용 | stoch/downtrend 필터 추가 |
| PnL 차이 | 위 문제들 복합 | 전체 모듈 교체 |

**결론**: `sandbox_backtest_v4.py`를 로컬에 그대로 복사하여 사용하는 것이 가장 확실합니다.

---

## 8. 파일 목록 (로컬 복사용)

| 파일 | 설명 | 경로 |
|------|------|------|
| `sandbox_backtest_v4.py` | 전체 백테스트 모듈 | `c:\매매전략\core\` |
| `PATTERN_EXTRACTION_CODE.md` | 패턴 추출 함수만 | 참조용 |
| `CRITICAL_DIFF_ANALYSIS.md` | 차이점 분석 | 참조용 |

---

*이 보고서를 로컬 AI에게 전달하여 수정 진행*
