# MACD 중심 코드 구조 분석 보고서

**분석일**: 2026-01-12  
**목적**: 샌드박스 모듈과 로컬 AlphaX7Core의 MACD 기반 계산식 비교  
**기준**: 사용자 모토 "MACD 기반"

---

## 1. 전체 시스템 구조 다이어그램

```mermaid
flowchart TB
    subgraph INPUT["📊 입력 데이터"]
        DATA["15분봉 OHLCV<br/>bybit_btcusdt_15m.parquet"]
    end
    
    subgraph SANDBOX["🔬 샌드박스 모듈<br/>sandbox_backtest_v4.py"]
        S_IND["calculate_indicators()"]
        S_MACD["detect_patterns_macd()<br/>MACD Hist 기반"]
        S_ADXDI["detect_patterns_adxdi()<br/>+DI/-DI 크로스"]
        S_BACK["run_backtest_core()"]
    end
    
    subgraph LOCAL["💻 로컬 AlphaX7Core<br/>strategy_core.py"]
        L_IND["_calculate_tr_atr()<br/>+ EMA/ADX 계산"]
        L_PATTERN["_extract_patterns()<br/>+DI/-DI 크로스"]
        L_FILTER["필터: ADX≥15, Vol≥0.8"]
        L_BACK["run_backtest()"]
    end
    
    DATA --> SANDBOX
    DATA --> LOCAL
    
    S_IND --> S_MACD
    S_IND --> S_ADXDI
    S_MACD --> S_BACK
    S_ADXDI --> S_BACK
    
    L_IND --> L_PATTERN
    L_PATTERN --> L_FILTER
    L_FILTER --> L_BACK
    
    style S_MACD fill:#4CAF50,color:#fff
    style L_PATTERN fill:#2196F3,color:#fff
```

---

## 2. MACD 패턴 탐지 로직 상세

### 2.1 샌드박스 MACD 방식 (사용자 모토)

```mermaid
flowchart LR
    subgraph MACD_CALC["MACD 계산"]
        EMA12["EMA(12)"]
        EMA26["EMA(26)"]
        MACD["MACD = EMA12 - EMA26"]
        SIG["Signal = EMA(MACD, 9)"]
        HIST["Hist = MACD - Signal"]
    end
    
    subgraph CROSS_DETECT["교차 감지"]
        NEG_POS["음→양 = 저점(L)"]
        POS_NEG["양→음 = 고점(H)"]
    end
    
    subgraph PATTERN["패턴 매칭"]
        W["L-H-L = W패턴<br/>→ Long"]
        M["H-L-H = M패턴<br/>→ Short"]
    end
    
    MACD_CALC --> CROSS_DETECT
    CROSS_DETECT --> PATTERN
    
    style NEG_POS fill:#4CAF50,color:#fff
    style POS_NEG fill:#f44336,color:#fff
```

### 2.2 코드 레벨 상세 (Line 234-309)

```python
# 샌드박스 MACD 패턴 탐지 핵심 로직
def detect_patterns_macd(df, tolerance=0.10, min_adx=0, min_vol_ratio=0.0):
    """
    MACD 히스토그램 기반 W/M 패턴 탐지
    """
    macd_hist = df['macd_hist'].values
    
    for i in range(30, len(df) - 10):
        # 저점(L): MACD Hist 음→양
        if macd_hist[i-1] < 0 and macd_hist[i] >= 0:
            window = df.iloc[max(0, i-10):i+1]
            trough_idx = window['low'].idxmin()  # 실제 저점 찾기
            hl_points.append({'type': 'L', ...})
        
        # 고점(H): MACD Hist 양→음
        if macd_hist[i-1] > 0 and macd_hist[i] <= 0:
            window = df.iloc[max(0, i-10):i+1]
            peak_idx = window['high'].idxmax()   # 실제 고점 찾기
            hl_points.append({'type': 'H', ...})
    
    # W패턴 매칭: L-H-L
    # M패턴 매칭: H-L-H
```

---

## 3. 샌드박스 vs 로컬 계산식 비교

```mermaid
flowchart TB
    subgraph COMPARE["🔬 핵심 차이점 비교"]
        direction TB
        
        subgraph SANDBOX_SIDE["샌드박스 모듈"]
            S1["패턴 탐지: MACD Hist 교차"]
            S2["ADX 필터: adx_min = 10"]
            S3["Volume 필터: 없음 (0.0)"]
            S4["Trail Start: 1.2R"]
            S5["Trail Dist: 0.03"]
            S6["시뮬 최대봉: 200봉"]
        end
        
        subgraph LOCAL_SIDE["로컬 AlphaX7Core"]
            L1["패턴 탐지: +DI/-DI 크로스"]
            L2["ADX 필터: adx_min = 15~20"]
            L3["Volume 필터: 0.8 (활성)"]
            L4["Trail Start: 0.6~0.8R"]
            L5["Trail Dist: 0.1"]
            L6["시뮬 최대봉: 101봉"]
        end
    end
    
    S1 <--> |"방식 차이"| L1
    S2 <--> |"로컬 더 엄격"| L2
    S3 <--> |"로컬에만 있음"| L3
    S4 <--> |"샌드박스 높음"| L4
    S5 <--> |"샌드박스 타이트"| L5
    S6 <--> |"샌드박스 길음"| L6
    
    style S1 fill:#4CAF50,color:#fff
    style L1 fill:#2196F3,color:#fff
```

---

## 4. 상세 비교표

| 항목 | 샌드박스 모듈 | 로컬 AlphaX7Core | 영향 |
|------|--------------|------------------|------|
| **패턴 탐지** | MACD Hist 교차 | +DI/-DI 크로스 | MACD가 더 빠른 신호 |
| **ADX 임계값** | `adx_min=10` | `min_adx_for_pattern=15~20` | 로컬 신호 ↓, 품질 ↑ |
| **Volume 필터** | `min_vol_ratio=0.0` | `min_vol_ratio=0.8` | 로컬에만 있음 |
| **Trail Start** | `1.2R` | `0.6~0.8R` | 샌드박스 늦게 시작 |
| **Trail Dist** | `0.03` | `0.1` | 샌드박스 더 타이트 |
| **시뮬레이션** | `200봉` | `101봉` | 샌드박스 더 오래 홀딩 |
| **EMA 필터** | EMA21 vs EMA50 | EMA 역추세 필터 | 유사 |
| **Stoch 필터** | Long<50, Short>50 | 선택적 | 동일 |

---

## 5. 지표 계산 흐름

```mermaid
flowchart LR
    subgraph OHLCV["원본 데이터"]
        O["Open"]
        H["High"]
        L["Low"]
        C["Close"]
        V["Volume"]
    end
    
    subgraph TR_ATR["변동성 지표"]
        TR["TR = max(H-L, |H-prev_C|, |L-prev_C|)"]
        ATR["ATR = SMA(TR, 14)"]
    end
    
    subgraph TREND["추세 지표"]
        EMA21["EMA(21)"]
        EMA50["EMA(50)"]
        TREND_FLAG["uptrend / downtrend"]
    end
    
    subgraph MACD_IND["MACD 지표"]
        MACD_LINE["MACD = EMA(12) - EMA(26)"]
        SIGNAL["Signal = EMA(MACD, 9)"]
        HISTOGRAM["Hist = MACD - Signal"]
    end
    
    subgraph ADX_IND["ADX/DI 지표"]
        PLUS_DI["+DI(14)"]
        MINUS_DI["-DI(14)"]
        ADX["ADX(14)"]
    end
    
    subgraph STOCH["Stochastic"]
        STOCH_K["%K(14)"]
    end
    
    OHLCV --> TR_ATR
    OHLCV --> TREND
    OHLCV --> MACD_IND
    OHLCV --> ADX_IND
    OHLCV --> STOCH
    
    style MACD_IND fill:#4CAF50,color:#fff
    style ADX_IND fill:#2196F3,color:#fff
```

---

## 6. 백테스트 결과 비교

```mermaid
pie showData
    title "단일 TF (2h) 승률 비교"
    "MACD 방식 (85.7%)" : 85.7
    "ADX/DI 방식 (82.2%)" : 82.2
```

### 6.1 성과 비교표

| 방식 | 구조 | 거래수 | 승률 | 단리 PnL | MDD |
|------|------|--------|------|----------|-----|
| **MACD** | 단일 2h | 349 | **85.7%** | 565.9% | 6.5% |
| ADX/DI | 단일 2h | 438 | 82.2% | 647.8% | 8.4% |
| **MACD** | MTF 4h/1h/15m | 769 | **82.8%** | 645.1% | 9.7% |
| ADX/DI | MTF 4h/1h/15m | 895 | 82.7% | 701.2% | 6.5% |
| 로컬 v2.3 | - | 105 | 63.8% | 8.8% | 10.6% |

### 6.2 MACD 방식의 장점

```mermaid
flowchart TB
    subgraph MACD_ADV["✅ MACD 방식 장점"]
        A1["더 높은 승률 (85.7%)"]
        A2["낮은 MDD (6.5%)"]
        A3["빠른 신호 포착"]
        A4["모멘텀 기반 신뢰성"]
    end
    
    subgraph ADXDI_ADV["⚠️ ADX/DI 방식 장점"]
        B1["더 많은 거래 기회 (438회)"]
        B2["더 높은 총 수익 (647.8%)"]
        B3["추세 강도 확인"]
    end
    
    style MACD_ADV fill:#4CAF50,color:#fff
    style ADXDI_ADV fill:#FF9800,color:#fff
```

---

## 7. 손절/트레일링 계산 흐름

```mermaid
flowchart TB
    subgraph ENTRY["진입"]
        E_PRICE["entry_price = 다음봉 시가"]
        ATR["ATR = 14봉 평균 TR"]
    end
    
    subgraph SL_CALC["손절 계산"]
        SL_LONG["Long SL = entry - ATR × 1.5"]
        SL_SHORT["Short SL = entry + ATR × 1.5"]
    end
    
    subgraph TRAIL["트레일링"]
        RISK["risk = |entry - SL|"]
        TS_START["trail_start = entry ± risk × 1.2R"]
        TS_DIST["trail_dist = risk × 0.03"]
    end
    
    subgraph SIM["시뮬레이션"]
        MAX_BAR["최대 200봉까지"]
        UPDATE["extreme_price 갱신"]
        SL_UPDATE["SL 상향 조정<br/>(수익 보호)"]
    end
    
    ENTRY --> SL_CALC
    SL_CALC --> TRAIL
    TRAIL --> SIM
    
    style TRAIL fill:#4CAF50,color:#fff
```

### 7.1 PnL 계산 공식

```
# Long 포지션
entry_adj = entry_price × (1 + slippage)
exit_adj  = exit_price × (1 - slippage)
pnl_pct   = (exit_adj - entry_adj) / entry_adj - fee × 2

# Short 포지션
entry_adj = entry_price × (1 - slippage)
exit_adj  = exit_price × (1 + slippage)
pnl_pct   = (entry_adj - exit_adj) / entry_adj - fee × 2

# 기본값
slippage = 0.0006 (0.06%)
fee = 0.00055 (0.055% 편도)
```

---

## 8. 로컬 통합 시 권장 방향

```mermaid
flowchart TB
    subgraph OPTION_A["🎯 권장: A 옵션 (MACD 중심)"]
        A1["샌드박스 MACD 모듈 채택"]
        A2["파라미터 조정:<br/>adx_min=15, vol_ratio=0.5"]
        A3["트레일링 유지:<br/>trail_start=1.2, trail_dist=0.03"]
    end
    
    subgraph OPTION_B["📊 대안: B 옵션 (하이브리드)"]
        B1["MACD + ADX/DI 듀얼 확인"]
        B2["MACD 신호 → ADX 필터 적용"]
        B3["더 보수적 진입"]
    end
    
    subgraph OPTION_C["⏸️ 보류: C 옵션"]
        C1["로컬 코드 대폭 수정"]
        C2["_extract_patterns → MACD 기반 변경"]
    end
    
    A1 --> A2 --> A3
    B1 --> B2 --> B3
    C1 --> C2
    
    style OPTION_A fill:#4CAF50,color:#fff
    style OPTION_B fill:#2196F3,color:#fff
    style OPTION_C fill:#9E9E9E,color:#fff
```

---

## 9. 핵심 파일 참조

| 파일 | 위치 | 핵심 함수/라인 |
|------|------|---------------|
| 샌드박스 MACD | `sandbox_backtest_v4.py` | `detect_patterns_macd()` (L234-309) |
| 샌드박스 ADX/DI | `sandbox_backtest_v4.py` | `detect_patterns_adxdi()` (L148-228) |
| 지표 계산 | `sandbox_backtest_v4.py` | `calculate_indicators()` (L77-142) |
| 로컬 패턴 | `strategy_core.py` | `_extract_patterns()` (L640-770) |
| 로컬 계산 | `calculations.py` | PnL 공식 (L1-375) |

---

## 10. 결론 및 다음 단계

### 10.1 핵심 발견

1. **MACD 방식이 승률에서 우위** (85.7% vs 82.2%)
2. **ADX/DI 방식이 거래수/총수익에서 우위** (438회, 647.8%)
3. **로컬 v2.3은 필터가 너무 엄격** (105회, 63.8%)

### 10.2 권장 조치

```
┌─────────────────────────────────────────────────────────────┐
│  🎯 A 옵션 (MACD 중심) 진행                                │
│                                                             │
│  1. 샌드박스 MACD 모듈을 로컬에 이식                       │
│  2. 파라미터 조정:                                          │
│     - adx_min: 10 → 12~15 (약간 엄격하게)                  │
│     - vol_ratio: 0.0 → 0.5 (적당히 필터)                   │
│     - trail: 유지 (1.2R, 0.03)                             │
│  3. 테스트 후 결과 비교                                     │
│                                                             │
│  B 옵션은 A 테스트 후 필요시 검토                          │
│  C 옵션은 추후 작업으로 보류                               │
└─────────────────────────────────────────────────────────────┘
```

---

**생성일**: 2026-01-12  
**버전**: v1.0  
**작성**: Genspark AI Sandbox
