# 샌드박스 패턴 추출 함수 코드 (그대로 복사용)

> **중요**: 아래 코드를 로컬 strategy_core.py에 **그대로 복사**하여 사용
> **파일**: sandbox_backtest_v4.py Line 143-331

---

## 1. ADX/DI 기반 패턴 탐지 (detect_patterns_adxdi)

```python
def detect_patterns_adxdi(
    df: pd.DataFrame, 
    tolerance: float = 0.10,
    min_adx: float = 10,
    min_vol_ratio: float = 0.0,  # 0이면 필터 안 함
) -> List[Dict]:
    """
    ADX/DI 기반 W/M 패턴 탐지 (로컬 v2.3과 동일한 로직)
    
    로직:
    - +DI > -DI 돌파 (Golden Cross) → 저점(L)
    - -DI > +DI 돌파 (Dead Cross) → 고점(H)
    - L-H-L → W 패턴 (Long)
    - H-L-H → M 패턴 (Short)
    
    필터 (로컬 v2.3):
    - ADX > min_adx (기본 15~20)
    - Volume Ratio > min_vol_ratio (기본 0.8)
    """
    patterns = []
    plus_di = df['plus_di'].values
    minus_di = df['minus_di'].values
    adx = df['adx'].values
    vol_ratio = df['vol_ratio'].values if 'vol_ratio' in df.columns else np.ones(len(df))
    
    hl_points = []
    
    for i in range(30, len(df) - 10):
        if pd.isna(plus_di[i-1]) or pd.isna(minus_di[i-1]):
            continue
        
        # Golden Cross (+DI > -DI) → 저점
        if plus_di[i-1] < minus_di[i-1] and plus_di[i] > minus_di[i]:
            window = df.iloc[max(0, i-10):i+1]
            trough_idx = window['low'].idxmin()
            hl_points.append({
                'type': 'L', 'idx': trough_idx,
                'price': df.loc[trough_idx, 'low'], 'bar_idx': i
            })
        
        # Dead Cross (-DI > +DI) → 고점
        if minus_di[i-1] < plus_di[i-1] and minus_di[i] > plus_di[i]:
            window = df.iloc[max(0, i-10):i+1]
            peak_idx = window['high'].idxmax()
            hl_points.append({
                'type': 'H', 'idx': peak_idx,
                'price': df.loc[peak_idx, 'high'], 'bar_idx': i
            })
    
    # W/M 패턴 매칭 + 필터
    for j in range(2, len(hl_points)):
        p1, p2, p3 = hl_points[j-2], hl_points[j-1], hl_points[j]
        bar_idx = p3['bar_idx']
        
        # [v2.3 필터] ADX + Volume
        if min_adx > 0 and (pd.isna(adx[bar_idx]) or adx[bar_idx] < min_adx):
            continue
        if min_vol_ratio > 0 and vol_ratio[bar_idx] < min_vol_ratio:
            continue
        
        # W 패턴 (L-H-L)
        if p1['type'] == 'L' and p2['type'] == 'H' and p3['type'] == 'L':
            swing = abs(p1['price'] - p3['price']) / p1['price']
            if swing <= tolerance:
                patterns.append({
                    'type': 'W', 'direction': 'Long',
                    'idx': p3['idx'], 'bar_idx': bar_idx,
                    'swing_diff': swing
                })
        
        # M 패턴 (H-L-H)
        elif p1['type'] == 'H' and p2['type'] == 'L' and p3['type'] == 'H':
            swing = abs(p1['price'] - p3['price']) / p1['price']
            if swing <= tolerance:
                patterns.append({
                    'type': 'M', 'direction': 'Short',
                    'idx': p3['idx'], 'bar_idx': bar_idx,
                    'swing_diff': swing
                })
    
    return patterns
```

---

## 2. MACD 기반 패턴 탐지 (detect_patterns_macd)

```python
def detect_patterns_macd(
    df: pd.DataFrame, 
    tolerance: float = 0.10,
    min_adx: float = 0,         # MACD 방식은 ADX 필터 선택적
    min_vol_ratio: float = 0.0,
) -> List[Dict]:
    """
    MACD 히스토그램 기반 W/M 패턴 탐지
    
    로직:
    - MACD Hist 음→양 → 저점(L)
    - MACD Hist 양→음 → 고점(H)
    - L-H-L → W 패턴 (Long)
    - H-L-H → M 패턴 (Short)
    """
    patterns = []
    macd_hist = df['macd_hist'].values
    adx = df['adx'].values if 'adx' in df.columns else np.zeros(len(df))
    vol_ratio = df['vol_ratio'].values if 'vol_ratio' in df.columns else np.ones(len(df))
    
    hl_points = []
    
    for i in range(30, len(df) - 10):
        if pd.isna(macd_hist[i-1]) or pd.isna(macd_hist[i]):
            continue
        
        # MACD Hist 음→양 = 저점 (L)
        if macd_hist[i-1] < 0 and macd_hist[i] >= 0:
            window = df.iloc[max(0, i-10):i+1]
            trough_idx = window['low'].idxmin()
            hl_points.append({
                'type': 'L', 'idx': trough_idx,
                'price': df.loc[trough_idx, 'low'], 'bar_idx': i
            })
        
        # MACD Hist 양→음 = 고점 (H)
        if macd_hist[i-1] > 0 and macd_hist[i] <= 0:
            window = df.iloc[max(0, i-10):i+1]
            peak_idx = window['high'].idxmax()
            hl_points.append({
                'type': 'H', 'idx': peak_idx,
                'price': df.loc[peak_idx, 'high'], 'bar_idx': i
            })
    
    # W/M 패턴 매칭
    for j in range(2, len(hl_points)):
        p1, p2, p3 = hl_points[j-2], hl_points[j-1], hl_points[j]
        bar_idx = p3['bar_idx']
        
        # 필터 (선택적)
        if min_adx > 0 and (pd.isna(adx[bar_idx]) or adx[bar_idx] < min_adx):
            continue
        if min_vol_ratio > 0 and vol_ratio[bar_idx] < min_vol_ratio:
            continue
        
        # W 패턴 (L-H-L)
        if p1['type'] == 'L' and p2['type'] == 'H' and p3['type'] == 'L':
            swing = abs(p1['price'] - p3['price']) / p1['price']
            if swing <= tolerance:
                patterns.append({
                    'type': 'W', 'direction': 'Long',
                    'idx': p3['idx'], 'bar_idx': bar_idx,
                    'swing_diff': swing
                })
        
        # M 패턴 (H-L-H)
        elif p1['type'] == 'H' and p2['type'] == 'L' and p3['type'] == 'H':
            swing = abs(p1['price'] - p3['price']) / p1['price']
            if swing <= tolerance:
                patterns.append({
                    'type': 'M', 'direction': 'Short',
                    'idx': p3['idx'], 'bar_idx': bar_idx,
                    'swing_diff': swing
                })
    
    return patterns
```

---

## 3. 핵심 차이점 비교

| 항목 | 샌드박스 | 로컬 확인 필요 |
|------|----------|----------------|
| **시작 인덱스** | `range(30, len(df) - 10)` | 동일한지? |
| **윈도우 크기** | `df.iloc[max(0, i-10):i+1]` | 동일한지? |
| **저점 탐색** | `window['low'].idxmin()` | 동일한지? |
| **고점 탐색** | `window['high'].idxmax()` | 동일한지? |
| **ADX 필터** | `adx[bar_idx] < min_adx` | 동일한지? |
| **Vol 필터** | `vol_ratio[bar_idx] < min_vol_ratio` | 동일한지? |
| **스윙 계산** | `abs(p1['price'] - p3['price']) / p1['price']` | 동일한지? |
| **필터 기본값** | `min_adx=10, min_vol_ratio=0.0` | 동일한지? |

---

## 4. 로컬 코드와 비교할 부분

### 검색 명령어 (로컬에서 실행)
```bash
grep -n "plus_di\|minus_di" strategy_core.py
grep -n "macd_hist" strategy_core.py
grep -n "idxmin\|idxmax" strategy_core.py
grep -n "range(30\|range(20" strategy_core.py
```

### 보고 형식
```
로컬 패턴 탐지 루프 시작: range(???, len(df) - ???)
로컬 윈도우 크기: df.iloc[max(0, i-???):i+???]
로컬 저점 탐색: ??? 
로컬 고점 탐색: ???
```

---

## 5. 거래수 차이 원인 추정

| 원인 | 샌드박스 | 로컬 예상 | 영향 |
|------|----------|-----------|------|
| 루프 시작점 | 30 | 50? | 신호 감소 |
| 윈도우 크기 | 10봉 | 5봉? | 극값 탐지 차이 |
| ADX 필터 | 10 | 20~30 | 신호 필터링 |
| Vol 필터 | 0.0 | 0.8~1.2 | 신호 필터링 |

**샌드박스 995거래 vs 로컬 37거래** = 약 **27배 차이**

---

## 6. 즉시 테스트 코드

로컬에서 패턴 수만 먼저 확인:

```python
# 패턴 수 비교 테스트
from sandbox_backtest_v4 import detect_patterns_adxdi, detect_patterns_macd, calculate_indicators

# 데이터 로드
df = pd.read_parquet('data/bybit_btcusdt_15m.parquet')
df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')

# 2h 리샘플링
df = df.set_index('timestamp').resample('2h').agg({
    'open': 'first', 'high': 'max', 'low': 'min',
    'close': 'last', 'volume': 'sum'
}).dropna().reset_index()

# 지표 계산
df = calculate_indicators(df)

# 패턴 탐지 (샌드박스 파라미터)
patterns_adxdi = detect_patterns_adxdi(df, tolerance=0.10, min_adx=10, min_vol_ratio=0.0)
patterns_macd = detect_patterns_macd(df, tolerance=0.10, min_adx=0, min_vol_ratio=0.0)

print(f"ADX/DI 패턴 수: {len(patterns_adxdi)}")  # 예상: ~1500+
print(f"MACD 패턴 수: {len(patterns_macd)}")      # 예상: ~1200+

# 로컬 패턴 탐지 함수로도 테스트
# patterns_local = local_extract_patterns(df, ...)
# print(f"로컬 패턴 수: {len(patterns_local)}")
```

**예상 결과:**
- 샌드박스 ADX/DI: ~1500+ 패턴 → ~1253 거래
- 샌드박스 MACD: ~1200+ 패턴 → ~995 거래
- 로컬: ~50 패턴? → ~37 거래

---

## 7. 파일 전체 복사 권장

**가장 확실한 해결책**: `sandbox_backtest_v4.py`를 로컬에 그대로 복사

```
복사 경로: c:\매매전략\core\sandbox_backtest_v4.py
```

그 후 로컬에서:
```python
from core.sandbox_backtest_v4 import run_single_tf_backtest, SANDBOX_PARAMS

result = run_single_tf_backtest(df, SANDBOX_PARAMS, timeframe='2h', method='macd')
print(result)
```

---

*이 코드를 로컬 AI에게 전달하여 패턴 탐지 로직 비교 요청*
