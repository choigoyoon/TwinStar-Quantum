# 로컬 AI 전달용 최종 프롬프트
## 샌드박스 vs 로컬 핵심 차이 4가지 확인 요청

---

## 배경

- **샌드박스 결과**: 995거래, 승률 86.13%, PnL +1937.89%, MDD 7.74%
- **로컬 결과**: 37~157거래, 승률 27~48%, PnL +9.9~272%, MDD 7.8~93%
- **문제**: 동일 데이터, 동일 파라미터에서 결과 불일치

---

## 확인해야 할 4가지 핵심 차이

### 1. 파라미터 키 이름 (가장 중요!)

**샌드박스 원본:**
```python
trail_start_r = params.get('trail_start', 1.2)   # 키: 'trail_start'
trail_dist_r = params.get('trail_dist', 0.03)    # 키: 'trail_dist'
```

**확인 요청:**
```bash
grep -n "trail_start" strategy_core.py
grep -n "trail_dist" strategy_core.py
```

**보고 형식:**
```
라인 XX: trail_start_r = params.get('키이름', 기본값)
라인 XX: trail_dist_r = params.get('키이름', 기본값)
```

### 2. PnL 계산 단위

**샌드박스 원본:**
```python
# PnL은 소수로 저장 (0.05 = 5%)
pnl_pct = (exit_adj - entry_adj) / entry_adj - fee * 2  # 결과: 0.05

# 복리 계산
capital *= (1 + pnl_pct)  # 0.05면 1.05배

# 출력시에만 100 곱함
simple_pnl = sum(pnls) * 100  # 0.05 → 5%
```

**확인 요청:**
```bash
grep -n "pnl_pct" strategy_core.py
grep -n "\* 100" strategy_core.py
grep -n "capital \*=" strategy_core.py
```

**보고 형식:**
```
PnL 계산식: pnl_pct = ???
PnL 저장 단위: 소수(0.05) / 퍼센트(5.0)
복리 계산식: capital *= ???
```

### 3. MDD 계산 방식

**샌드박스 원본:**
```python
equity = np.array(equity)
peak = np.maximum.accumulate(equity)  # numpy 벡터
drawdown = (equity - peak) / peak * 100
max_dd = abs(drawdown.min())
```

**확인 요청:**
```bash
grep -n "drawdown\|max_dd\|mdd" strategy_core.py
```

### 4. max_bars 기본값

**샌드박스 원본:**
```python
max_bars: int = 100  # 기본값 100
```

**확인 요청:**
```bash
grep -n "max_bars\|max_sim_bars" strategy_core.py
```

---

## 즉시 수정 코드 (복사용)

### 파라미터 키 통일 수정
```python
# 두 키 모두 지원하도록 수정
trail_start_r = params.get('trail_start_r', params.get('trail_start', 1.2))
trail_dist_r = params.get('trail_dist_r', params.get('trail_dist', 0.03))
```

### PnL 계산 검증 (로컬에서 실행)
```python
# 단일 거래 PnL 검증
entry = 50000
exit_price = 52500  # +5%
slippage = 0.0006
fee = 0.00055

entry_adj = entry * (1 + slippage)
exit_adj = exit_price * (1 - slippage)
pnl_pct = (exit_adj - entry_adj) / entry_adj - fee * 2

print(f"PnL (소수): {pnl_pct:.4f}")        # 샌드박스 예상: 0.0477
print(f"PnL (퍼센트): {pnl_pct*100:.2f}%")  # 샌드박스 예상: 4.77%

# 로컬에서 동일한 결과가 나오는지 확인
```

---

## 보고 양식

아래 표를 채워서 보고:

| 항목 | 샌드박스 | 로컬 | 일치여부 |
|------|----------|------|----------|
| trail_start 키 | `trail_start` | `???` | ⬜ |
| trail_dist 키 | `trail_dist` | `???` | ⬜ |
| trail_start 기본값 | 1.2 | ??? | ⬜ |
| trail_dist 기본값 | 0.03 | ??? | ⬜ |
| PnL 단위 | 소수 | ??? | ⬜ |
| max_bars | 100 | ??? | ⬜ |

---

## 테스트 코드 (수정 후 실행)

```python
# 샌드박스 파라미터로 테스트
SANDBOX_PARAMS = {
    'trail_start': 1.2,      # 키 확인!
    'trail_dist': 0.03,      # 키 확인!
    'adx_min': 10,
    'tolerance': 0.10,
    'atr_mult': 1.5,
    'stoch_long_max': 50,
    'stoch_short_min': 50,
}

# 실행
result = run_backtest(df, SANDBOX_PARAMS, pattern_method='macd')
print(f"거래수: {result['trades']}, 승률: {result['win_rate']}%, PnL: {result['compound_pnl']}%")
```

**예상 결과** (샌드박스와 일치시):
- 거래수: ~995
- 승률: ~86%
- PnL: ~1938%
- MDD: ~7.7%

---

## 파일 참조

- `CRITICAL_DIFF_ANALYSIS.md` - 상세 차이점 분석
- `sandbox_backtest_v4.py` - 샌드박스 원본 모듈 (Line 363-534)
- `sandbox_backtest_v4_ORIGINAL.py` - 백업

---

**이 프롬프트의 핵심 요청:**
1. 위 4가지 항목을 로컬 코드에서 확인
2. 차이점 발견시 샌드박스 기준으로 수정
3. 수정 후 재테스트하여 결과 보고
