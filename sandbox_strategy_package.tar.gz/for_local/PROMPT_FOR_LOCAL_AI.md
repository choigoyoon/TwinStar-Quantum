# 로컬 AI 전달용 프롬프트

---

## 작업 배경

샌드박스 환경에서 **MACD 기반 백테스트 모듈**을 개발 완료했습니다.
사용자의 모토가 "MACD 기반"이므로, **MACD 중심으로 진행 방향**을 잡았습니다.

---

## 핵심 발견 사항

### 성과 비교 (BTCUSDT 2024년 데이터)

| 방식 | 구조 | 거래수 | 승률 | 단리 PnL | MDD |
|------|------|--------|------|----------|-----|
| **MACD** | 단일 2h | 349 | **85.7%** | 565.9% | 6.5% |
| ADX/DI | 단일 2h | 438 | 82.2% | 647.8% | 8.4% |
| 로컬 v2.3 | - | 105 | 63.8% | 8.8% | 10.6% |

### 결론
- **MACD 방식이 승률에서 우위** (85.7% vs 82.2%)
- **로컬 v2.3은 필터가 너무 엄격** → 거래 기회 손실

---

## 핵심 차이점 (샌드박스 vs 로컬)

| 항목 | 샌드박스 | 로컬 v2.3 | 영향 |
|------|----------|-----------|------|
| 패턴 탐지 | MACD Hist 교차 | +DI/-DI 크로스 | MACD 더 빠름 |
| ADX 임계값 | adx_min=10 | adx_min=15~20 | 로컬 신호 감소 |
| Volume 필터 | 없음 (0.0) | vol_ratio=0.8 | 로컬에만 있음 |
| Trail Start | 1.2R | 0.6R | 샌드박스 늦게 |
| Trail Dist | 0.03 | 0.1 | 샌드박스 타이트 |
| 시뮬레이션 | 200봉 | 101봉 | 샌드박스 오래 |

---

## 작업 요청

### A 옵션 (권장): MACD 모듈 로컬 이식

**1. 파일 복사**
```
sandbox_backtest_v4.py → c:\매매전략\core\
test_compare_ab.py     → c:\매매전략\
```

**2. 테스트 실행**
```bash
cd c:\매매전략
python test_compare_ab.py
```

**3. 결과 보고 양식**
| 테스트 | 거래수 | 승률 | 단리 PnL | MDD |
|--------|--------|------|----------|-----|
| A: 새모듈_MACD |  |  |  |  |
| A: 새모듈_ADXDI |  |  |  |  |
| B: 기존_v2.3 |  |  |  |  |

---

## 전달 파일 목록

| 파일 | 용도 | 크기 |
|------|------|------|
| `sandbox_backtest_v4.py` | MACD/ADX 듀얼 백테스트 모듈 | ~32KB |
| `test_compare_ab.py` | A vs B 비교 테스트 스크립트 | ~11KB |
| `MACD_CENTRIC_ANALYSIS_REPORT.md` | MD 다이어그램 분석 보고서 | ~9KB |

---

## 로컬에서 확인할 사항

1. **데이터 파일 경로**: `c:\매매전략\data\bybit_btcusdt_15m.parquet`
2. **AlphaX7Core import 가능 여부**: `from core.strategy_core import AlphaX7Core`
3. **기존 v2.3 백테스트 실행 가능 여부**

---

## MACD 패턴 탐지 로직 (핵심)

```python
def detect_patterns_macd(df, tolerance=0.10):
    """
    MACD 히스토그램 기반 W/M 패턴 탐지
    
    로직:
    - MACD Hist 음→양 = 저점(L)
    - MACD Hist 양→음 = 고점(H)
    - L-H-L = W패턴 → Long
    - H-L-H = M패턴 → Short
    """
    macd_hist = df['macd_hist'].values
    
    for i in range(30, len(df) - 10):
        if macd_hist[i-1] < 0 and macd_hist[i] >= 0:  # 저점
            hl_points.append({'type': 'L', ...})
        if macd_hist[i-1] > 0 and macd_hist[i] <= 0:  # 고점
            hl_points.append({'type': 'H', ...})
    
    # W패턴: L-H-L → Long
    # M패턴: H-L-H → Short
```

---

## 손절/트레일링 계산

```python
# 손절
stop_loss = entry_price - atr * 1.5  # Long
stop_loss = entry_price + atr * 1.5  # Short

# 트레일링
risk = abs(entry_price - stop_loss)
trail_start = entry_price + risk * 1.2
trail_dist = risk * 0.03

# 시뮬레이션 (200봉)
if extreme_price >= trail_start:
    current_sl = max(current_sl, extreme_price - trail_dist)
```

---

## 파라미터 권장값

### MACD 방식 (A 옵션)
```python
MACD_PARAMS = {
    'adx_min': 10,
    'tolerance': 0.10,
    'atr_mult': 1.5,
    'trail_start': 1.2,
    'trail_dist': 0.03,
}
```

### 로컬 v2.3 호환 (B 옵션)
```python
LOCAL_V23_PARAMS = {
    'adx_min': 20,
    'tolerance': 0.11,
    'trail_start': 0.6,
    'trail_dist': 0.1,
    'min_vol_ratio': 0.8,
}
```

---

## 다음 단계

1. 로컬에서 A vs B 테스트 실행
2. 결과 비교 후 더 나은 옵션 선택
3. 선택된 옵션을 실매매 적용 검토

---

**작성일**: 2026-01-12
**작성**: Genspark AI Sandbox
