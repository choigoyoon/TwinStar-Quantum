# 샌드박스 모듈 로컬 통합 가이드

## 개요

샌드박스에서 검증된 백테스트 모듈을 로컬 AlphaX7 프로젝트에 통합합니다.

---

## 테스트 결과 (2024년 BTCUSDT)

| 설정 | 거래수 | 승률 | 단리 PnL |
|------|--------|------|----------|
| **샌드박스 ADX/DI** | 427 | 82.0% | **629.6%** |
| **샌드박스 MACD** | 347 | 85.6% | 561.5% |
| **로컬 v2.3 파라미터** | 154 | **96.8%** | 188.1% |

### 핵심 차이

| 파라미터 | 로컬 v2.3 | 샌드박스 | 효과 |
|----------|-----------|----------|------|
| `adx_min` | 20 | 10 | 거래수 2.7배 증가 |
| `min_vol_ratio` | 0.8 | 없음 | 추가 필터 제거 |
| `trail_dist` | 0.1 | 0.03 | 수익 극대화 |
| `trail_start` | 0.6 | 1.2 | 트레일링 시작점 |

---

## 파일 복사

### 1. 샌드박스 모듈 복사

```
sandbox_backtest_v4.py → c:\매매전략\core\sandbox_backtest_v4.py
test_compare_ab.py     → c:\매매전략\test_compare_ab.py
```

### 2. 디렉토리 구조

```
c:\매매전략\
├── core/
│   ├── strategy_core.py        # 기존 (유지)
│   ├── optimization_logic.py   # 기존 (유지)
│   └── sandbox_backtest_v4.py  # 🆕 추가
├── config/
│   └── parameters.py           # 기존 (유지)
└── test_compare_ab.py          # 🆕 추가
```

---

## 사용법

### 기본 import

```python
from core.sandbox_backtest_v4 import (
    # 통합 함수
    run_single_tf_backtest,
    run_mtf_backtest,
    
    # 개별 함수
    run_backtest_adxdi,     # ADX/DI (로컬 v2.3 방식)
    run_backtest_macd,      # MACD (사용자 모토)
    
    # 파라미터 프리셋
    SANDBOX_PARAMS,         # 샌드박스 기본 (고수익)
    LOCAL_V23_PARAMS,       # 로컬 v2.3 호환 (고승률)
)
```

### 단일 TF 백테스트

```python
import pandas as pd

# 데이터 로드
df = pd.read_parquet('data/bybit_btcusdt_15m.parquet')

# 방식 1: 샌드박스 파라미터 (고수익)
result = run_backtest_adxdi(df, SANDBOX_PARAMS, timeframe='2h')
print(f"거래: {result['trades']}, 승률: {result['win_rate']}%, PnL: {result['simple_pnl']}%")

# 방식 2: 로컬 v2.3 파라미터 (고승률)
result = run_backtest_adxdi(df, LOCAL_V23_PARAMS, timeframe='2h')
print(f"거래: {result['trades']}, 승률: {result['win_rate']}%, PnL: {result['simple_pnl']}%")

# 방식 3: MACD 기반 (사용자 모토)
result = run_backtest_macd(df, SANDBOX_PARAMS, timeframe='2h')
```

### 3-TF MTF 백테스트

```python
from core.sandbox_backtest_v4 import run_mtf_backtest

# MTF: 필터(4h) / 패턴(1h) / 진입(15m)
result = run_mtf_backtest(
    df,
    params=SANDBOX_PARAMS,
    filter_tf='4h',
    pattern_tf='1h',
    entry_tf='15m',
    method='adxdi'  # 또는 'macd'
)
```

### 커스텀 파라미터

```python
my_params = {
    'stoch_long_max': 50,
    'stoch_short_min': 50,
    'adx_min': 15,              # 로컬(20)과 샌드박스(10) 중간
    'tolerance': 0.10,
    'atr_mult': 1.5,
    'trail_start': 1.0,         # 조정
    'trail_dist': 0.05,         # 로컬(0.1)과 샌드박스(0.03) 중간
    'min_vol_ratio': 0.0,       # 볼륨 필터 비활성화
}

result = run_single_tf_backtest(df, my_params, '2h', method='adxdi')
```

---

## A vs B 비교 테스트

```bash
cd c:\매매전략
python test_compare_ab.py
```

### 예상 출력

```
====================================================================
A vs B 비교 테스트
====================================================================

옵션 A: 샌드박스 모듈 (sandbox_backtest_v4.py)
------------------------------------------------------------
ADX/DI 2h: 427거래, 82.0% 승률, 629.6% PnL, MDD 8.4%
MACD 2h:   347거래, 85.6% 승률, 561.5% PnL, MDD 6.5%
v2.3 ADX/DI: 154거래, 96.8% 승률, 188.1% PnL, MDD 2.1%

옵션 B: 로컬 AlphaX7Core (strategy_core.py)
------------------------------------------------------------
로컬 v2.3: 105거래, 63.8% 승률, 8.8% PnL

📊 결론:
  - 샌드박스 모듈이 동일 데이터에서 더 높은 성과
  - 차이 원인: 트레일링 파라미터 (trail_dist)
```

---

## 기존 코드와의 통합 (옵션)

### optimization_logic.py에 추가

```python
# optimization_logic.py

# 샌드박스 모듈 추가 (선택적)
try:
    from sandbox_backtest_v4 import run_single_tf_backtest as sandbox_backtest
    USE_SANDBOX = True
except ImportError:
    USE_SANDBOX = False

class UnifiedOptimizer:
    def _evaluate_params(self, params):
        if USE_SANDBOX and self.use_sandbox_calc:
            # 샌드박스 백테스트 사용
            result = sandbox_backtest(
                self.df_entry,
                params,
                timeframe='2h',
                method='adxdi'
            )
            if result:
                return OptimizationResult(
                    params=params,
                    trades=result['trades'],
                    win_rate=result['win_rate'],
                    total_return=result['simple_pnl'],
                    ...
                )
        else:
            # 기존 로직 사용
            return self._legacy_evaluate(params)
```

---

## 파라미터 권장값

### 고수익 추구

```python
HIGH_PROFIT_PARAMS = {
    'adx_min': 10,
    'trail_start': 1.2,
    'trail_dist': 0.03,
    'min_vol_ratio': 0.0,
}
# 예상: 400+ 거래, 82% 승률, 600%+ PnL
```

### 고승률 추구

```python
HIGH_WINRATE_PARAMS = {
    'adx_min': 20,
    'trail_start': 0.6,
    'trail_dist': 0.1,
    'min_vol_ratio': 0.8,
}
# 예상: 150 거래, 96% 승률, 180% PnL
```

### 균형형

```python
BALANCED_PARAMS = {
    'adx_min': 15,
    'trail_start': 0.9,
    'trail_dist': 0.05,
    'min_vol_ratio': 0.5,
}
# 예상: 250 거래, 88% 승률, 350% PnL
```

---

## 버전 히스토리

- **v4.0** (2026-01-12): 로컬 이식용 듀얼 모듈 생성
  - ADX/DI + MACD 방식 지원
  - 단일 TF + MTF 지원
  - 로컬 v2.3 파라미터 호환

---

## 문의

샌드박스 환경에서 검증된 모듈입니다.
로컬 환경에서 문제 발생 시 데이터 형식을 확인하세요:
- timestamp: int64 (ms) 또는 datetime
- 필수 컬럼: open, high, low, close, volume
