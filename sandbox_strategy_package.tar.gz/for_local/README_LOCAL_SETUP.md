# 🚀 샌드박스 전략 로컬 설치 가이드

## 📦 파일 구성

```
for_local/
├── sandbox_strategy_complete.py    ⭐ 메인 파일 (백테스트 + 최적화)
├── sandbox_backtest_v4_ORIGINAL.py  원본 백테스트 (참조용)
├── sandbox_backtest_v4.py           확장 버전
├── test_compare_ab.py               A/B 비교 테스트
└── README_LOCAL_SETUP.md            이 파일
```

---

## ⚡ 빠른 시작

### 1. 파일 복사
```bash
# Windows
copy for_local\*.py c:\매매전략\core\

# Linux/Mac
cp for_local/*.py ~/trading/core/
```

### 2. 사용 예시

```python
from sandbox_strategy_complete import (
    run_backtest, 
    run_optimization,
    SANDBOX_PARAMS, 
    HYBRID_OPTIMAL_PARAMS,
    compare_params
)
import pandas as pd

# 데이터 로드
df = pd.read_parquet('data/bybit_btcusdt_15m.parquet')

# 단일 백테스트
result = run_backtest(df, SANDBOX_PARAMS, timeframe='2h')
print(f"승률: {result['win_rate']:.1f}%, PnL: {result['simple_pnl']:.1f}%")

# 파라미터 비교
compare_params(df, '2h')

# 최적화 실행
results = run_optimization(df, timeframe='2h')
```

---

## 🏆 검증된 파라미터

### ⭐ HYBRID_OPTIMAL (권장)
```python
HYBRID_OPTIMAL_PARAMS = {
    'atr_mult': 1.5,
    'trail_start': 1.2,
    'trail_dist': 0.03,
    'tolerance': 0.12,
    'adx_min': 5,
}
# 성과: 84.9% 승률, 1077거래, +1615.2% PnL (5년)
```

### SANDBOX_ORIGINAL
```python
SANDBOX_PARAMS = {
    'atr_mult': 1.5,
    'trail_start': 1.2,
    'trail_dist': 0.03,
    'tolerance': 0.10,
    'adx_min': 10,
}
# 성과: 84.7% 승률, 1053거래, +1542.0% PnL (5년)
```

### LOCAL_v2.3 (보수적)
```python
LOCAL_V23_PARAMS = {
    'atr_mult': 1.5,
    'trail_start': 0.6,
    'trail_dist': 0.1,
    'tolerance': 0.11,
    'adx_min': 20,
}
# 성과: 92.4% 승률, 746거래, +689.5% PnL (5년)
```

---

## 📊 핵심 파라미터 설명

| 파라미터 | 설명 | 권장값 | 영향 |
|---------|------|--------|------|
| `atr_mult` | 손절 거리 (ATR 배수) | 1.5 | 클수록 넓은 손절 |
| `trail_start` | 트레일링 시작점 (R 배수) | **1.2** | ⭐ 핵심! 클수록 늦게 트레일링 |
| `trail_dist` | 트레일링 거리 (R 배수) | **0.03** | ⭐ 핵심! 작을수록 타이트 |
| `tolerance` | 패턴 허용 오차 | 0.10~0.12 | 클수록 더 많은 패턴 |
| `adx_min` | 최소 ADX 필터 | 5~10 | 작을수록 더 많은 신호 |

### 🔑 핵심 발견
> **`trail_start=1.2` + `trail_dist=0.03` 조합이 높은 승률의 핵심!**
> - 1.2R 도달 후 트레일링 시작 → 조기 청산 방지
> - 0.03R 타이트한 트레일링 → 수익 보존

---

## 💰 비용 설정

```python
DEFAULT_SLIPPAGE = 0.0006   # 0.06%
DEFAULT_FEE = 0.00055       # 0.055% (편도)
TOTAL_COST = 0.00115        # 0.115% (왕복)
```

---

## 📈 성능 비교 (BTCUSDT 2h, 2020년~)

| 파라미터 | 거래 | 승률 | 단리 PnL | MDD |
|---------|------|------|----------|-----|
| **HYBRID_OPTIMAL** ⭐ | 1077 | 84.9% | +1615.2% | 7.1% |
| SANDBOX_ORIGINAL | 1053 | 84.7% | +1542.0% | 6.0% |
| MAX_PROFIT | 1077 | 70.9% | +1999.2% | 10.0% |
| LOCAL_v2.3 | 746 | 92.4% | +689.5% | 5.5% |

---

## 🔧 로컬 코드 수정 가이드

기존 로컬 코드에서 수정해야 할 부분:

### 1. trail_start 변경
```python
# 기존 (로컬)
trail_start_r = 0.6   # ❌

# 수정 (샌드박스)
trail_start_r = 1.2   # ✅
```

### 2. trail_dist 변경
```python
# 기존 (로컬)
trail_dist_r = 0.1    # ❌

# 수정 (샌드박스)
trail_dist_r = 0.03   # ✅
```

### 3. adx_min 변경
```python
# 기존 (로컬)
adx_min = 20          # ❌ 너무 엄격

# 수정 (샌드박스)
adx_min = 10          # ✅ 또는 5
```

---

## ⚠️ 주의사항

1. **데이터 형식**: timestamp는 밀리초 또는 datetime 형식 지원
2. **필수 컬럼**: open, high, low, close, volume, timestamp
3. **최소 데이터**: 100봉 이상 필요 (2h 기준)
4. **비용 반영**: slippage + fee 자동 반영됨

---

## 📞 문의

샌드박스 AI 생성 | 버전: v4.1 | 날짜: 2026-01-13
