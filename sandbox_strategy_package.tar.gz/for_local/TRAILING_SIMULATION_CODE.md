# 샌드박스 트레일링 시뮬레이션 코드 (전체)

> **핵심**: 거래수는 비슷한데 승률 40% 차이 → 트레일링 로직이 원인
> **파일**: sandbox_backtest_v4.py Line 422-534

---

## 전체 코드 (복사용)

```python
# ========== 진입 ==========
entry_idx = idx + 1
if entry_idx >= len(df_work):
    continue

entry_row = df_work.iloc[entry_idx]
entry_price = entry_row['open']  # ⚠️ 진입가: 다음 봉의 시가

# SL 계산
if direction == 'Long':
    stop_loss = entry_price - atr * atr_mult  # Long: 진입가 - ATR*배수
else:
    stop_loss = entry_price + atr * atr_mult  # Short: 진입가 + ATR*배수

# 트레일링 파라미터
risk = abs(entry_price - stop_loss)  # 리스크 = |진입가 - SL|
if direction == 'Long':
    trail_start_price = entry_price + risk * trail_start_r  # Long: 진입가 + 리스크*1.2
else:
    trail_start_price = entry_price - risk * trail_start_r  # Short: 진입가 - 리스크*1.2
trail_distance = risk * trail_dist_r  # 트레일링 거리 = 리스크*0.03

# ========== 트레일링 시뮬레이션 ==========
current_sl = stop_loss
extreme_price = entry_price  # ⚠️ 초기 극값 = 진입가
exit_price = None

for j in range(entry_idx + 1, min(entry_idx + max_bars, len(df_work))):
    bar = df_work.iloc[j]
    high, low = bar['high'], bar['low']
    
    if direction == 'Long':
        # 1. SL 히트 체크 (먼저!)
        if low <= current_sl:
            exit_price = current_sl  # ⚠️ SL 가격으로 청산 (슬리피지 없이)
            break
        
        # 2. 신고가 갱신
        if high > extreme_price:
            extreme_price = high
        
        # 3. 트레일링 SL 상향 (trail_start 도달 후에만)
        if extreme_price >= trail_start_price:
            potential_sl = extreme_price - trail_distance
            if potential_sl > current_sl:  # ⚠️ SL은 올리기만 함
                current_sl = potential_sl
    
    else:  # Short
        # 1. SL 히트 체크 (먼저!)
        if high >= current_sl:
            exit_price = current_sl  # ⚠️ SL 가격으로 청산 (슬리피지 없이)
            break
        
        # 2. 신저가 갱신
        if low < extreme_price:
            extreme_price = low
        
        # 3. 트레일링 SL 하향 (trail_start 도달 후에만)
        if extreme_price <= trail_start_price:
            potential_sl = extreme_price + trail_distance
            if potential_sl < current_sl:  # ⚠️ SL은 내리기만 함
                current_sl = potential_sl

# 만료 청산 (max_bars 도달시)
if exit_price is None:
    last_bar = df_work.iloc[min(entry_idx + max_bars - 1, len(df_work) - 1)]
    exit_price = last_bar['close']  # ⚠️ 마지막 봉의 종가로 청산

# PnL 계산
if direction == 'Long':
    entry_adj = entry_price * (1 + slippage)   # 진입: 슬리피지 추가
    exit_adj = exit_price * (1 - slippage)     # 청산: 슬리피지 차감
    pnl_pct = (exit_adj - entry_adj) / entry_adj - fee * 2  # 수수료 2회
else:
    entry_adj = entry_price * (1 - slippage)   # Short 진입: 슬리피지 차감
    exit_adj = exit_price * (1 + slippage)     # Short 청산: 슬리피지 추가
    pnl_pct = (entry_adj - exit_adj) / entry_adj - fee * 2

trades.append({
    'direction': direction,
    'entry_price': entry_price,
    'exit_price': exit_price,
    'pnl_pct': pnl_pct,
    'is_win': pnl_pct > 0,
})
```

---

## 핵심 차이점 체크리스트

### 1. 진입가 결정

| 항목 | 샌드박스 | 로컬 확인 |
|------|----------|-----------|
| 진입 시점 | `idx + 1` (다음 봉) | ??? |
| 진입 가격 | `entry_row['open']` (시가) | ??? |

```bash
grep -n "entry_price\|entry_row" strategy_core.py
```

### 2. SL 계산

| 항목 | 샌드박스 | 로컬 확인 |
|------|----------|-----------|
| Long SL | `entry_price - atr * atr_mult` | ??? |
| Short SL | `entry_price + atr * atr_mult` | ??? |
| atr_mult | 1.5 | ??? |

```bash
grep -n "stop_loss\|atr_mult" strategy_core.py
```

### 3. 트레일링 파라미터 ⚠️ 핵심!

| 항목 | 샌드박스 | 로컬 확인 |
|------|----------|-----------|
| **trail_start_r** | **1.2** (1.2R) | ??? |
| **trail_dist_r** | **0.03** (0.03R) | ??? |
| risk 계산 | `abs(entry_price - stop_loss)` | ??? |

```bash
grep -n "trail_start\|trail_dist\|risk" strategy_core.py
```

### 4. 트레일링 시뮬레이션 순서 ⚠️ 중요!

**샌드박스 순서 (Long):**
1. `if low <= current_sl:` → 청산 (먼저!)
2. `if high > extreme_price:` → 신고가 갱신
3. `if extreme_price >= trail_start_price:` → SL 상향

**로컬 순서 확인:**
```bash
grep -A 20 "def simulate\|trailing" strategy_core.py
```

### 5. 청산 가격 결정

| 상황 | 샌드박스 | 로컬 확인 |
|------|----------|-----------|
| SL 히트 | `exit_price = current_sl` | ??? |
| 만료 | `last_bar['close']` | ??? |

### 6. PnL 계산

| 항목 | 샌드박스 | 로컬 확인 |
|------|----------|-----------|
| slippage | 0.0006 (0.06%) | ??? |
| fee | 0.00055 (0.055%) | ??? |
| **PnL 단위** | **소수 (0.05 = 5%)** | ??? |

---

## 로컬 코드와 비교할 핵심 질문

### Q1. 초기 extreme_price 값은?

**샌드박스:**
```python
extreme_price = entry_price  # 진입가로 초기화
```

**로컬 확인:**
```bash
grep -n "extreme_price" strategy_core.py
```

### Q2. trail_start 조건 체크는?

**샌드박스:**
```python
if extreme_price >= trail_start_price:  # 도달 후에만 트레일링
```

**로컬 확인:** 
- 트레일링이 바로 시작하는지? (trail_start 없이)
- 아니면 특정 수익 도달 후 시작하는지?

### Q3. SL 업데이트 조건은?

**샌드박스:**
```python
if potential_sl > current_sl:  # Long: 올리기만
if potential_sl < current_sl:  # Short: 내리기만
```

**로컬 확인:**
- SL이 역방향으로 움직이지는 않는지?

### Q4. 청산 가격은 SL 가격 그대로?

**샌드박스:**
```python
exit_price = current_sl  # SL 가격 그대로 사용
```

**로컬 확인:**
- `bar['low']` 또는 `bar['high']`를 사용하는지?
- 슬리피지가 여기서 적용되는지?

---

## 단일 거래 검증 코드

로컬에서 실행하여 비교:

```python
# 단일 거래 시뮬레이션 검증
entry_price = 50000
atr = 500
atr_mult = 1.5
trail_start_r = 1.2
trail_dist_r = 0.03
direction = 'Long'

# 계산
stop_loss = entry_price - atr * atr_mult  # 49250
risk = abs(entry_price - stop_loss)       # 750
trail_start_price = entry_price + risk * trail_start_r  # 50900
trail_distance = risk * trail_dist_r      # 22.5

print(f"진입가: {entry_price}")
print(f"초기 SL: {stop_loss}")
print(f"리스크: {risk}")
print(f"트레일링 시작가: {trail_start_price}")
print(f"트레일링 거리: {trail_distance}")

# 시나리오: 가격이 51000까지 상승 후 50950까지 하락
extreme_price = 51000
current_sl = stop_loss

if extreme_price >= trail_start_price:
    potential_sl = extreme_price - trail_distance  # 51000 - 22.5 = 50977.5
    if potential_sl > current_sl:
        current_sl = potential_sl

print(f"트레일링 후 SL: {current_sl}")  # 예상: 50977.5

# 50950에서 SL 히트?
test_low = 50950
if test_low <= current_sl:
    print(f"SL 히트! 청산가: {current_sl}")  # 50977.5 >= 50950 → 히트!
```

**예상 결과:**
```
진입가: 50000
초기 SL: 49250
리스크: 750
트레일링 시작가: 50900
트레일링 거리: 22.5
트레일링 후 SL: 50977.5
SL 히트! 청산가: 50977.5
```

---

## 가장 가능성 높은 차이점

### 1. trail_dist 값 차이

| 항목 | 샌드박스 | 로컬 예상 |
|------|----------|-----------|
| trail_dist | **0.03** (3%) | **0.1** (10%)? |

**영향:** 
- 0.03 = 타이트한 트레일링 → 수익 극대화
- 0.1 = 느슨한 트레일링 → 더 많은 수익 반납

### 2. trail_start 값 차이

| 항목 | 샌드박스 | 로컬 예상 |
|------|----------|-----------|
| trail_start | **1.2R** | **0.6R**? |

**영향:**
- 1.2R = 충분히 수익 난 후 트레일링 시작
- 0.6R = 너무 일찍 트레일링 → 조기 청산

### 3. 시뮬레이션 순서 차이

**샌드박스:** SL 체크 → 신고가 갱신 → 트레일링  
**로컬:** 신고가 갱신 → 트레일링 → SL 체크? (순서 다르면 결과 달라짐)

---

## 즉시 확인 요청

```bash
# 로컬에서 실행
grep -n "trail_start\|trail_dist" strategy_core.py
grep -n "extreme_price\|current_sl" strategy_core.py
grep -n "potential_sl" strategy_core.py
```

**보고 형식:**
```
trail_start_r 값: ???
trail_dist_r 값: ???
시뮬레이션 순서: [SL체크→신고가→트레일링] or [다른순서]
```

---

*이 코드를 로컬 strategy_core.py와 한 줄씩 비교하여 차이점 찾기*
