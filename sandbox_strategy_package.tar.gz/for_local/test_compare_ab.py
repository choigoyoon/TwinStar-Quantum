#!/usr/bin/env python3
"""
A vs B 비교 테스트 스크립트
===========================

로컬에서 실행하여 두 가지 방식 비교:
  A: 샌드박스 모듈 (sandbox_backtest_v4.py)
  B: 로컬 strategy_core.py (AlphaX7Core)

사용법:
-------
1. sandbox_backtest_v4.py를 c:\매매전략\core\ 에 복사
2. 이 파일을 c:\매매전략\ 에 복사
3. 실행: python test_compare_ab.py

버전: 1.0
작성일: 2026-01-12
"""

import pandas as pd
import numpy as np
import sys
import os
from datetime import datetime

# 경로 설정 (로컬 환경에 맞게 수정)
PROJECT_ROOT = r"c:\매매전략"
sys.path.insert(0, PROJECT_ROOT)
sys.path.insert(0, os.path.join(PROJECT_ROOT, "core"))


def load_data(data_path: str = None) -> pd.DataFrame:
    """
    테스트 데이터 로드
    
    로컬 데이터 경로 예시:
    - c:\매매전략\data\bybit_btcusdt_15m.parquet
    - c:\매매전략\data\BTCUSDT_15m.csv
    """
    if data_path is None:
        # 가능한 경로들
        possible_paths = [
            os.path.join(PROJECT_ROOT, "data", "bybit_btcusdt_15m.parquet"),
            os.path.join(PROJECT_ROOT, "data", "BTCUSDT_15m.parquet"),
            os.path.join(PROJECT_ROOT, "parquet", "bybit_btcusdt_15m.parquet"),
        ]
        
        for path in possible_paths:
            if os.path.exists(path):
                data_path = path
                break
        
        if data_path is None:
            raise FileNotFoundError(f"데이터 파일을 찾을 수 없습니다. 경로: {possible_paths}")
    
    print(f"[DATA] 로드: {data_path}")
    
    if data_path.endswith('.parquet'):
        df = pd.read_parquet(data_path)
    else:
        df = pd.read_csv(data_path)
    
    # 타임스탬프 변환
    if 'timestamp' in df.columns:
        if df['timestamp'].dtype == 'int64':
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
    
    # 2024년 이후만 사용 (테스트용)
    df = df[df['timestamp'] >= '2024-01-01'].reset_index(drop=True)
    
    print(f"[DATA] 로드 완료: {len(df):,}행, {df['timestamp'].min()} ~ {df['timestamp'].max()}")
    
    return df


def test_option_a(df: pd.DataFrame) -> dict:
    """
    옵션 A: 샌드박스 모듈 테스트
    """
    print("\n" + "=" * 60)
    print("옵션 A: 샌드박스 모듈 (sandbox_backtest_v4.py)")
    print("=" * 60)
    
    try:
        from sandbox_backtest_v4 import (
            run_backtest_adxdi,
            run_backtest_macd,
            run_mtf_backtest_adxdi,
            run_mtf_backtest_macd,
            SANDBOX_PARAMS,
            LOCAL_V23_PARAMS,
        )
        
        results = {}
        
        # 1. 샌드박스 파라미터 + ADX/DI
        print("\n--- 샌드박스 파라미터 ---")
        r1 = run_backtest_adxdi(df, SANDBOX_PARAMS, '2h')
        if r1:
            print(f"ADX/DI 2h: {r1['trades']}거래, {r1['win_rate']}% 승률, {r1['simple_pnl']}% PnL, MDD {r1['max_mdd']}%")
            results['sandbox_adxdi'] = r1
        
        # 2. 샌드박스 파라미터 + MACD
        r2 = run_backtest_macd(df, SANDBOX_PARAMS, '2h')
        if r2:
            print(f"MACD 2h:   {r2['trades']}거래, {r2['win_rate']}% 승률, {r2['simple_pnl']}% PnL, MDD {r2['max_mdd']}%")
            results['sandbox_macd'] = r2
        
        # 3. 로컬 v2.3 파라미터로 테스트
        print("\n--- 로컬 v2.3 파라미터 (ADX>20, vol>0.8, trail_dist=0.1) ---")
        r3 = run_backtest_adxdi(df, LOCAL_V23_PARAMS, '2h')
        if r3:
            print(f"v2.3 ADX/DI: {r3['trades']}거래, {r3['win_rate']}% 승률, {r3['simple_pnl']}% PnL, MDD {r3['max_mdd']}%")
            results['local_v23_adxdi'] = r3
        
        # 4. MTF 테스트
        print("\n--- MTF (4h/1h/15m) ---")
        r4 = run_mtf_backtest_adxdi(df, SANDBOX_PARAMS, '4h', '1h', '15m')
        if r4:
            print(f"MTF ADX/DI: {r4['trades']}거래, {r4['win_rate']}% 승률, {r4['simple_pnl']}% PnL, MDD {r4['max_mdd']}%")
            results['mtf_adxdi'] = r4
        
        r5 = run_mtf_backtest_macd(df, SANDBOX_PARAMS, '4h', '1h', '15m')
        if r5:
            print(f"MTF MACD:   {r5['trades']}거래, {r5['win_rate']}% 승률, {r5['simple_pnl']}% PnL, MDD {r5['max_mdd']}%")
            results['mtf_macd'] = r5
        
        return results
    
    except ImportError as e:
        print(f"[ERROR] sandbox_backtest_v4 import 실패: {e}")
        print("       sandbox_backtest_v4.py를 core/ 폴더에 복사했는지 확인하세요.")
        return {}


def test_option_b(df: pd.DataFrame) -> dict:
    """
    옵션 B: 로컬 strategy_core.py 테스트
    """
    print("\n" + "=" * 60)
    print("옵션 B: 로컬 AlphaX7Core (strategy_core.py)")
    print("=" * 60)
    
    try:
        from strategy_core import AlphaX7Core
        
        results = {}
        
        # AlphaX7Core 초기화
        core = AlphaX7Core(use_mtf=True)
        
        # 1시간봉 리샘플링
        df_1h = df.copy()
        df_1h['timestamp'] = pd.to_datetime(df_1h['timestamp'])
        df_1h = df_1h.set_index('timestamp').resample('1h').agg({
            'open': 'first', 'high': 'max', 'low': 'min',
            'close': 'last', 'volume': 'sum'
        }).dropna().reset_index()
        
        print(f"\n데이터: 15m {len(df):,}행, 1h {len(df_1h):,}행")
        
        # 백테스트 실행 (로컬 기본 파라미터)
        print("\n--- 로컬 기본 파라미터 ---")
        trades = core.run_backtest(
            df_pattern=df_1h,
            df_entry=df,
            atr_mult=1.5,
            trail_start_r=0.6,
            trail_dist_r=0.1,
            pattern_tolerance=0.11,
            filter_tf='4h',
        )
        
        if trades:
            pnls = [t['pnl'] for t in trades]
            wins = [p for p in pnls if p > 0]
            win_rate = len(wins) / len(pnls) * 100 if pnls else 0
            total_pnl = sum(pnls)
            
            print(f"로컬 v2.3: {len(trades)}거래, {win_rate:.2f}% 승률, {total_pnl:.2f}% PnL")
            results['local_core'] = {
                'trades': len(trades),
                'win_rate': round(win_rate, 2),
                'simple_pnl': round(total_pnl, 2),
            }
        else:
            print("거래 없음")
        
        # 샌드박스 파라미터로 로컬 코어 테스트
        print("\n--- 샌드박스 파라미터로 로컬 코어 테스트 ---")
        trades2 = core.run_backtest(
            df_pattern=df_1h,
            df_entry=df,
            atr_mult=1.5,
            trail_start_r=1.2,     # 샌드박스
            trail_dist_r=0.03,    # 샌드박스
            pattern_tolerance=0.10,
            filter_tf='4h',
        )
        
        if trades2:
            pnls2 = [t['pnl'] for t in trades2]
            wins2 = [p for p in pnls2 if p > 0]
            win_rate2 = len(wins2) / len(pnls2) * 100 if pnls2 else 0
            total_pnl2 = sum(pnls2)
            
            print(f"로컬+샌드박스 파람: {len(trades2)}거래, {win_rate2:.2f}% 승률, {total_pnl2:.2f}% PnL")
            results['local_sandbox_params'] = {
                'trades': len(trades2),
                'win_rate': round(win_rate2, 2),
                'simple_pnl': round(total_pnl2, 2),
            }
        
        return results
    
    except ImportError as e:
        print(f"[ERROR] strategy_core import 실패: {e}")
        return {}
    except Exception as e:
        print(f"[ERROR] 로컬 테스트 실패: {e}")
        import traceback
        traceback.print_exc()
        return {}


def print_comparison(results_a: dict, results_b: dict):
    """비교 결과 출력"""
    print("\n" + "=" * 70)
    print("📊 A vs B 비교 결과")
    print("=" * 70)
    
    print("""
┌─────────────────────────────┬─────────┬─────────┬───────────┬────────┐
│ 테스트                      │ 거래수  │ 승률    │ 단리 PnL  │ MDD    │
├─────────────────────────────┼─────────┼─────────┼───────────┼────────┤""")
    
    # 옵션 A 결과
    for key, r in results_a.items():
        trades = r.get('trades', '-')
        wr = r.get('win_rate', '-')
        pnl = r.get('simple_pnl', '-')
        mdd = r.get('max_mdd', '-')
        print(f"│ A: {key:<24} │ {trades:>7} │ {wr:>6}% │ {pnl:>8}% │ {mdd:>5}% │")
    
    print("├─────────────────────────────┼─────────┼─────────┼───────────┼────────┤")
    
    # 옵션 B 결과
    for key, r in results_b.items():
        trades = r.get('trades', '-')
        wr = r.get('win_rate', '-')
        pnl = r.get('simple_pnl', '-')
        mdd = r.get('max_mdd', '-') if 'max_mdd' in r else '-'
        print(f"│ B: {key:<24} │ {trades:>7} │ {wr:>6}% │ {pnl:>8}% │ {mdd:>5} │")
    
    print("└─────────────────────────────┴─────────┴─────────┴───────────┴────────┘")
    
    # 결론
    print("\n📋 결론:")
    
    a_best = max(results_a.values(), key=lambda x: x.get('simple_pnl', 0)) if results_a else None
    b_best = max(results_b.values(), key=lambda x: x.get('simple_pnl', 0)) if results_b else None
    
    if a_best and b_best:
        if a_best.get('simple_pnl', 0) > b_best.get('simple_pnl', 0):
            print("  ✅ 옵션 A (샌드박스 모듈)가 더 높은 수익")
            print(f"     {a_best.get('simple_pnl')}% vs {b_best.get('simple_pnl')}%")
        else:
            print("  ✅ 옵션 B (로컬 코어)가 더 높은 수익")
            print(f"     {b_best.get('simple_pnl')}% vs {a_best.get('simple_pnl')}%")
    
    print("\n💡 권장 사항:")
    print("  1. 샌드박스 파라미터(trail_dist=0.03)가 수익 극대화에 효과적")
    print("  2. ADX 임계값을 10~15로 완화하면 거래 기회 증가")
    print("  3. Volume 필터는 선택적으로 적용 (승률 vs 거래수 트레이드오프)")


def main():
    """메인 실행"""
    print("=" * 70)
    print("A vs B 비교 테스트")
    print("A: 샌드박스 모듈 (sandbox_backtest_v4.py)")
    print("B: 로컬 strategy_core.py (AlphaX7Core)")
    print("=" * 70)
    print(f"실행 시간: {datetime.now()}")
    
    # 데이터 로드
    try:
        df = load_data()
    except FileNotFoundError as e:
        print(f"\n[ERROR] {e}")
        print("\n데이터 경로를 확인하고 다시 실행하세요.")
        return
    
    # 옵션 A 테스트
    results_a = test_option_a(df)
    
    # 옵션 B 테스트
    results_b = test_option_b(df)
    
    # 비교 결과
    print_comparison(results_a, results_b)
    
    print("\n" + "=" * 70)
    print("테스트 완료")
    print("=" * 70)


if __name__ == "__main__":
    main()
